##
## global.pl: Global variables for RM DEMO
## Need to set enviroment variable RMSCRIPTS (path name for RM scripts)
##      for the whole scripts to work.
##
##      TL 7/1998
##

$RMWORK="Z\:\\htk_test\\samples\\RMHTK\\work";
$RMLIB="Z\:\\htk_test\\samples\\RMHTK\\lib";
$RMDATA="Z\:\\htk_test\\samples\\RMHTK\\data";
$RMCD1="Z\:\\htk_test\\CD_NIST2_3_1";
$RMCD2="Z\:\\htk_test\\RM1_CD_2_4_2";
$RMCD3="Z\:\\htk_test\\CD1_NIST2_1_1";

1;
